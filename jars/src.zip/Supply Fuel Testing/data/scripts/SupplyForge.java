package data.scripts;

import java.awt.Color;

import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.fleet.FleetMemberViewAPI;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.impl.campaign.abilities.BaseToggleAbility;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.plugins.SFPlugin;

public class SupplyForge extends BaseToggleAbility {
	public static final Color CONTRAIL_COLOR = new Color(255, 97, 27, 80);

    public float getSupplyPerMetal() {
        return (Global.getSettings().getFloat("SF_MetalConversionRate")
                * (Global.getSector().getEconomy().getCommoditySpec(Commodities.HEAVY_MACHINERY).getBasePrice() + 5*Global.getSector().getEconomy().getCommoditySpec(Commodities.METALS).getBasePrice())
                / Global.getSector().getEconomy().getCommoditySpec(Commodities.SUPPLIES).getBasePrice())
                ;//* ;
    }
    public int MoreCoom() {
        return Global.getSettings().getInt("UseExtraCommodities");
    }
    float MetalCost = Global.getSettings().getFloat("SF_MetalCost");
    float HeavyMachineryCost = Global.getSettings().getFloat("SF_HeavyMachineryCost");
    float CorruptedMetalMultiplier = Global.getSettings().getFloat("SF_CorruptedMetal");
    float PristineMetalMultiplier = Global.getSettings().getFloat("SF_PristineMetal");
    
    @Override
    protected String getActivationText() {
        /*        if (Commodities.HEAVY_MACHINERY != null
        && Commodities.METALS != null
        && getFleet() != null
        || (getFleet().getCargo().getCommodityQuantity(Commodities.METALS) <= 0
        || getFleet().getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) <= 0
        || getFleet().getCargo().getSupplies() >= getFleet().getCargo().getMaxCapacity())) {
        return null;
        } else */return null;
    }

    @Override
    protected void activateImpl() { }

    @Override
    public boolean showActiveIndicator() { return isActive(); }

    @Override
    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
        //Color gray = Misc.getGrayColor();
        Color highlight = Misc.getHighlightColor();

        String status = " (off)";
        if (turnedOn) {
                status = " (on)";
        }

        LabelAPI title = tooltip.addTitle(spec.getName() + status);
        title.highlightLast(status);
        title.setHighlightColor(highlight);

        float pad = 10f;
        tooltip.addPara("Smelt Metals using Heavy Machinery into Supplies.", pad);
            String Supply = Misc.getRoundedValueMaxOneAfterDecimal(getSupplyPerMetal());
            float iCoom = iCalculateBonus();
            if (iCoom > 1) {Supply = Misc.getRoundedValueMaxOneAfterDecimal(getSupplyPerMetal()*iCoom);}
            String canOrIs = isActive() ? "are smelting" : "can smelt";
            String Based = iCoom > 1 ? "Nanoforges in your inventory are improving the process of forging supplies by": "You do not possess a nanoforge that can hasten the process.";
            String Based2 = iCoom > 1 ? Misc.getRoundedValue((iCoom-1)*100) + "%." : "";
            tooltip.addPara("Your fleet's autoforges " + canOrIs + " %s units of Metal with %s units of Heavy Machinery to create %s Supplies on a daily basis.",
                        pad, Misc.getTextColor(), Misc.getRoundedValueMaxOneAfterDecimal(MetalCost*iCoom), Misc.getRoundedValueMaxOneAfterDecimal(HeavyMachineryCost*iCoom), Supply);
            if (MoreCoom() > 0) {
                for (int i = 0; i < MoreCoom(); i++) {
                    tooltip.addPara("Additionally using %s " + Global.getSettings().getCommoditySpec(Global.getSettings().getString("ExtraCommodities" + i)).getName() + ".",
                    pad*0.2f, Misc.getTextColor(), Misc.getRoundedValueMaxOneAfterDecimal((Global.getSettings().getFloat("ExtraCommoditiesCost" + i))));
                }
            };
            tooltip.addPara("%s %s", pad, highlight, Based, Based2);
            tooltip.addPara("Increases the range at which the fleet can be detected by %s.",
                        pad, Misc.getNegativeHighlightColor(), (int)SFPlugin.SENSOR_PROFILE_INCREASE_PERCENT + "%");


        addIncompatibleToTooltip(tooltip, expanded);
    }

    @Override
    public boolean hasTooltip() { return true; }

    @Override
    protected void applyEffect(float amount, float level) {
        CampaignFleetAPI fleet = getFleet();
        if (fleet == null) return;
        
        if(!isActive()) return;
        
        fleet.getStats().getDetectedRangeMod().modifyPercent(getModId(), SFPlugin.SENSOR_PROFILE_INCREASE_PERCENT, "Supply Forging");

        float days = Global.getSector().getClock().convertToDays(amount);
        float cost = days;
        float supply = fleet.getCargo().getCommodityQuantity(Commodities.SUPPLIES);
        if (MoreCoom() > 0) {
            if(fleet.getCargo().getCommodityQuantity(Commodities.METALS) <= 0 || fleet.getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) <= 0) {
                fleet.addFloatingText("Out of Resources", Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate(); 
            } else if(supply >= fleet.getCargo().getMaxCapacity()) {
                fleet.addFloatingText("Full of Supplies", Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate();
            } else {
                float basedmodifier = iCalculateBonus();
                for (int i = 0; i < MoreCoom(); i++) {
                    if (fleet.getCargo().getCommodityQuantity(Global.getSettings().getString("ExtraCommodities" + i)) <= 0) {
                        fleet.addFloatingText("Out of " + Global.getSettings().getCommoditySpec(Global.getSettings().getString("ExtraCommodities" + i)).getName(), Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f); deactivate();  break;
                    }
                    fleet.getCargo().removeCommodity(Global.getSettings().getString("ExtraCommodities" + i), cost*Global.getSettings().getFloat("ExtraCommoditiesCost" + i));
                }
                fleet.getCargo().removeCommodity(Commodities.METALS, cost*MetalCost*basedmodifier);
                fleet.getCargo().removeCommodity(Commodities.HEAVY_MACHINERY, cost*HeavyMachineryCost*basedmodifier);
                fleet.getCargo().addCommodity(Commodities.SUPPLIES, cost*getSupplyPerMetal()*basedmodifier);

                            for (FleetMemberViewAPI view : getFleet().getViews()) {
                                    view.getContrailColor().shift("timidhavenoidea", CONTRAIL_COLOR, getActivationDays(), 2, 1f);
                                    view.getContrailWidthMult().shift("timidhavenoidea", 6, getActivationDays(), 2, 1f);
                            }
            }
        } else{
            if(fleet.getCargo().getCommodityQuantity(Commodities.METALS) <= 0 || fleet.getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) <= 0) {
                fleet.addFloatingText("Out of Metals or Heavy Machinery", Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate(); 
            } else if(supply >= fleet.getCargo().getMaxCapacity()) {
                fleet.addFloatingText("Full of Supplies", Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate();
            } else {
                float basedmodifier = iCalculateBonus();
                fleet.getCargo().removeCommodity(Commodities.METALS, cost*MetalCost*basedmodifier);
                fleet.getCargo().removeCommodity(Commodities.HEAVY_MACHINERY, cost*HeavyMachineryCost*basedmodifier);
                fleet.getCargo().addCommodity(Commodities.SUPPLIES, cost*getSupplyPerMetal()*basedmodifier);

                            for (FleetMemberViewAPI view : getFleet().getViews()) {
                                    view.getContrailColor().shift("timidhavenoidea", CONTRAIL_COLOR, getActivationDays(), 2, 1f);
                                    view.getContrailWidthMult().shift("timidhavenoidea", 6, getActivationDays(), 2, 1f);
                            }
            }
        }
    }

    @Override
    public boolean isUsable() {
        //return isActive();
        return true;
    }
    
    public float iCalculateBonus() {
        float iCorrupted = getFleet().getCargo().getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null));
        float iPristine = getFleet().getCargo().getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null));
        int iShipSize = Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy().size();
        float iMaxBonus = PristineMetalMultiplier*iShipSize;
        if (iCorrupted > iShipSize) {
            iCorrupted = iShipSize;
        };
        float iBonus = CorruptedMetalMultiplier*iCorrupted+PristineMetalMultiplier*iPristine;
        if (iBonus > iMaxBonus) {
            iBonus = iMaxBonus;
        };
        return iBonus+1;
    }

    @Override
    protected void deactivateImpl() { cleanupImpl(); }

    @Override
    protected void cleanupImpl() {
        CampaignFleetAPI fleet = getFleet();
        if (fleet == null) return;
        
        fleet.getStats().getDetectedRangeMod().unmodify(getModId());
    }
}