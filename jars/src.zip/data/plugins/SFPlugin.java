package data.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

public class SFPlugin extends BaseModPlugin {
    public static final String ID = "supply_forge";
    public static final String ABILITY_ID = "timid_supply_forge";
    public static float SENSOR_PROFILE_INCREASE_PERCENT = 300f;

    @Override
    public void afterGameSave() {
        Global.getSector().getCharacterData().addAbility(ABILITY_ID);
    }

    @Override
    public void beforeGameSave() {
        Global.getSector().getCharacterData().removeAbility(ABILITY_ID);
    }

    @Override
    public void onGameLoad(boolean newGame) {
        try {
            if(!Global.getSector().getPlayerFleet().hasAbility(ABILITY_ID)) {
                Global.getSector().getCharacterData().addAbility(ABILITY_ID);
            }
        SENSOR_PROFILE_INCREASE_PERCENT = (float) Global.getSettings().getFloat("SupplyForgingSensorProfileIncreasePercent");
        } catch (Exception e) {
            String stackTrace = "";

            for(int i = 0; i < e.getStackTrace().length; i++) {
                StackTraceElement ste = e.getStackTrace()[i];
                stackTrace += "    " + ste.toString() + System.lineSeparator();
            }

            Global.getLogger(SFPlugin.class).error(e.getMessage() + System.lineSeparator() + stackTrace);
        }
    }
}
