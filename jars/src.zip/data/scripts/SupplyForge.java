package data.scripts;

import java.awt.Color;

import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.fleet.FleetMemberViewAPI;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.RepairGantry;
import com.fs.starfarer.api.impl.campaign.abilities.BaseToggleAbility;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.plugins.SFPlugin;
import java.util.List;

public class SupplyForge extends BaseToggleAbility {
	public static final Color CONTRAIL_COLOR = new Color(255, 97, 27, 80);

    public float getSupplyPerMetal() {
        return (Global.getSettings().getFloat("SF_MetalConversionRate")
                * (Global.getSector().getEconomy().getCommoditySpec(Commodities.HEAVY_MACHINERY).getBasePrice() + 5*Global.getSector().getEconomy().getCommoditySpec(Commodities.METALS).getBasePrice())
                / Global.getSector().getEconomy().getCommoditySpec(Commodities.SUPPLIES).getBasePrice())
                ;//* ;
    }
    public int MoreCoom() {
        return Global.getSettings().getInt("UseExtraCommodities");
    }
    float MetalCost = Global.getSettings().getFloat("SF_MetalCost");
    float HeavyMachineryCost = Global.getSettings().getFloat("SF_HeavyMachineryCost");
    //float CorruptedMetalMultiplier = Global.getSettings().getFloat("SF_CorruptedMetal");
    //float PristineMetalMultiplier = Global.getSettings().getFloat("SF_PristineMetal");
    //float SalvageModifier = Global.getSettings().getFloat("SF_SalvageGantry");
    boolean affectInput = Global.getSettings().getBoolean("SF_Input");
    boolean affectOutput = Global.getSettings().getBoolean("SF_Output");
    
    @Override
    protected String getActivationText() {
        /*        if (Commodities.HEAVY_MACHINERY != null
        && Commodities.METALS != null
        && getFleet() != null
        || (getFleet().getCargo().getCommodityQuantity(Commodities.METALS) <= 0
        || getFleet().getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) <= 0
        || getFleet().getCargo().getSupplies() >= getFleet().getCargo().getMaxCapacity())) {
        return null;
        } else */return null;
    }

    @Override
    protected void activateImpl() { }

    @Override
    public boolean showActiveIndicator() { return isActive(); }

    @Override
    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
        //Color gray = Misc.getGrayColor();
        Color highlight = Misc.getHighlightColor();

        String status = " (off)";
        if (turnedOn) {
                status = " (on)";
        }
        if (Global.getSettings().isShowingCodex()) {
            tooltip.addTitle(spec.getName());
        } else {
            LabelAPI title = tooltip.addTitle(spec.getName() + status);
            title.highlightLast(status);
            title.setHighlightColor(highlight);
        }

        float pad = 10f;
        tooltip.addPara(Global.getSettings().getString("supplyforging", "1"), pad);
        if (!Global.getSettings().isShowingCodex()){
            float iCoom = iCalculateBonus();
            String Supply = Misc.getRoundedValueMaxOneAfterDecimal(getSupplyPerMetal()*iCoom);
            String canOrIs = isActive() ? Global.getSettings().getString("supplyforging", "2") : Global.getSettings().getString("supplyforging", "3");
            String Based = iCoom > 1 ? Global.getSettings().getString("supplyforging", "5") : Global.getSettings().getString("supplyforging", "6");
            String Based2 = iCoom > 1 ? Misc.getRoundedValue((iCoom-1)*100) + "%." : "";
            tooltip.addPara(String.format(Global.getSettings().getString("supplyforging", "4"), canOrIs, Misc.getRoundedValueMaxOneAfterDecimal(MetalCost*iCoom), Misc.getRoundedValueMaxOneAfterDecimal(HeavyMachineryCost*iCoom), Supply), pad, Misc.getTextColor(), Misc.getRoundedValueMaxOneAfterDecimal(MetalCost*iCoom), Misc.getRoundedValueMaxOneAfterDecimal(HeavyMachineryCost*iCoom), Supply);
            if (MoreCoom() > 0) {
                for (int i = 0; i < MoreCoom(); i++) {
                    tooltip.addPara(String.format(Global.getSettings().getString("supplyforging", "7"), Misc.getRoundedValueMaxOneAfterDecimal((Global.getSettings().getFloat("ExtraCommoditiesCost" + i))*iCoom), Global.getSettings().getCommoditySpec(Global.getSettings().getString("ExtraCommodities" + i)).getName()),
                    pad*0.2f, Misc.getTextColor(), Misc.getRoundedValueMaxOneAfterDecimal((Global.getSettings().getFloat("ExtraCommoditiesCost" + i))*iCoom));
                }
            };
            tooltip.addPara("%s %s", pad, highlight, Based, Based2);
        }
        if (Global.getSettings().isShowingCodex()) {
            tooltip.addPara(String.format(Global.getSettings().getString("supplyforging", "14"), Misc.getRoundedValue(Global.getSettings().getFloat("SF_Frigate")*100f)+"%",  Misc.getRoundedValue(Global.getSettings().getFloat("SF_Destroyer")*100f)+"%",  Misc.getRoundedValue(Global.getSettings().getFloat("SF_Cruiser")*100f)+"%",  Misc.getRoundedValue(Global.getSettings().getFloat("SF_Capital")*100f)+"%"), pad);
        }
            tooltip.addPara(Global.getSettings().getString("supplyforging", "8"),
                        pad, Misc.getNegativeHighlightColor(), (int)SFPlugin.SENSOR_PROFILE_INCREASE_PERCENT + "%");

        addIncompatibleToTooltip(tooltip, expanded);
    }

    @Override
    public boolean hasTooltip() { return true; }

    @Override
    protected void applyEffect(float amount, float level) {
        CampaignFleetAPI fleet = getFleet();
        if (fleet == null) return;
        
        if(!isActive()) return;
        
        fleet.getStats().getDetectedRangeMod().modifyPercent(getModId(), SFPlugin.SENSOR_PROFILE_INCREASE_PERCENT, Global.getSettings().getString("supplyforging", "15"));

        float days = Global.getSector().getClock().convertToDays(amount);
        float cost = days;
        float supply = fleet.getCargo().getCommodityQuantity(Commodities.SUPPLIES);
        if (MoreCoom() > 0) {
            if(fleet.getCargo().getCommodityQuantity(Commodities.METALS) <= 0 || fleet.getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) <= 0) {
                fleet.addFloatingText(Global.getSettings().getString("supplyforging", "9"), Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate(); 
            } else if(supply >= fleet.getCargo().getMaxCapacity()) {
                fleet.addFloatingText(Global.getSettings().getString("supplyforging", "10"), Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate();
            } else {
                float basedmodifier = iCalculateBonus();
                    for (int i = 0; i < MoreCoom(); i++) {
                        if (fleet.getCargo().getCommodityQuantity(Global.getSettings().getString("ExtraCommodities" + i)) <= 0) {
                            fleet.addFloatingText(Global.getSettings().getString("supplyforging", "11")+ Global.getSettings().getCommoditySpec(Global.getSettings().getString("ExtraCommodities" + i)).getName(), Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f); deactivate();  break;
                        }
                        fleet.getCargo().removeCommodity(Global.getSettings().getString("ExtraCommodities" + i), cost*Global.getSettings().getFloat("ExtraCommoditiesCost" + i)*basedmodifier);
                    }
                fleet.getCargo().removeCommodity(Commodities.METALS, cost*MetalCost*(affectInput ? basedmodifier : 1));
                fleet.getCargo().removeCommodity(Commodities.HEAVY_MACHINERY, cost*HeavyMachineryCost*(affectInput ? basedmodifier : 1));
                fleet.getCargo().addCommodity(Commodities.SUPPLIES, cost*getSupplyPerMetal()*(affectOutput ? basedmodifier : 1));
                for (FleetMemberViewAPI view : getFleet().getViews()) {
                    view.getContrailColor().shift("timidhavenoidea", CONTRAIL_COLOR, getActivationDays(), 2, 1f);
                    view.getContrailWidthMult().shift("timidhavenoidea", 6, getActivationDays(), 2, 1f);
                }
            }
        } else{
            if(fleet.getCargo().getCommodityQuantity(Commodities.METALS) <= 0 || fleet.getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) <= 0) {
                fleet.addFloatingText(Global.getSettings().getString("supplyforging", "12"), Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate(); 
            } else if(supply >= fleet.getCargo().getMaxCapacity()) {
                fleet.addFloatingText(Global.getSettings().getString("supplyforging", "13"), Misc.setAlpha(entity.getIndicatorColor(), 255), 0.5f);
                deactivate();
            } else {
                float basedmodifier = iCalculateBonus();
                if (affectInput) {fleet.getCargo().removeCommodity(Commodities.METALS, cost*MetalCost*basedmodifier);fleet.getCargo().removeCommodity(Commodities.HEAVY_MACHINERY, cost*HeavyMachineryCost*basedmodifier);} else {fleet.getCargo().removeCommodity(Commodities.METALS, cost*MetalCost);fleet.getCargo().removeCommodity(Commodities.HEAVY_MACHINERY, cost*HeavyMachineryCost);}
                if (affectOutput) {fleet.getCargo().addCommodity(Commodities.SUPPLIES, cost*getSupplyPerMetal()*basedmodifier);} else {fleet.getCargo().addCommodity(Commodities.SUPPLIES, cost*getSupplyPerMetal());}
                for (FleetMemberViewAPI view : getFleet().getViews()) {
                    view.getContrailColor().shift("timidhavenoidea", CONTRAIL_COLOR, getActivationDays(), 2, 1f);
                    view.getContrailWidthMult().shift("timidhavenoidea", 6, getActivationDays(), 2, 1f);
                }
            }
        }
    }

    @Override
    public boolean isUsable() {
        //return isActive();
        return true;
    }
    
    public float iCalculateBonus() {
        //float iCorrupted = getFleet().getCargo().getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null));
        //float iPristine = getFleet().getCargo().getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null));
        float iSalvageCoomer = 0f;
        List<FleetMemberAPI> playerFleetList = Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy();
        //int iShipSize = playerFleetList.size();
        for (FleetMemberAPI member : playerFleetList) {
            if (member.isMothballed()) continue;
            if (!member.isCivilian()) continue;
            if (member.getRepairTracker().getCR() < 0.1f) continue;
            if (member.isFrigate()) iSalvageCoomer = iSalvageCoomer+Global.getSettings().getFloat("SF_Frigate");
            if (member.isDestroyer()) iSalvageCoomer = iSalvageCoomer+Global.getSettings().getFloat("SF_Destroyer");
            if (member.isCruiser()) iSalvageCoomer = iSalvageCoomer+Global.getSettings().getFloat("SF_Cruiser");
            if (member.isCapital()) iSalvageCoomer = iSalvageCoomer+Global.getSettings().getFloat("SF_Capital");
        }
        
        //float iMaxBonus = PristineMetalMultiplier*iShipSize+SalvageModifier*iSalvageCoomer;
        //if (iCorrupted > iShipSize) {
        //    iCorrupted = iShipSize;
        //};
        //float iBonus = CorruptedMetalMultiplier*iCorrupted+PristineMetalMultiplier*iPristine+SalvageModifier*iSalvageCoomer;
        //if (iBonus > iMaxBonus) {
        //    iBonus = iMaxBonus;
        //};
        return (RepairGantry.getAdjustedGantryModifier(Global.getSector().getPlayerFleet(), null, 0f)+1)*(iSalvageCoomer+1);
    }

    @Override
    protected void deactivateImpl() { cleanupImpl(); }

    @Override
    protected void cleanupImpl() {
        CampaignFleetAPI fleet = getFleet();
        if (fleet == null) return;
        
        fleet.getStats().getDetectedRangeMod().unmodify(getModId());
    }
}